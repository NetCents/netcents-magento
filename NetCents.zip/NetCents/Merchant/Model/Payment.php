<?php

namespace NetCents\Merchant\Model;

use Braintree\Exception;
use NetCents\Merchant\Library\NCWidgetClient\NCPaymentData;
use NetCents\Merchant\Library\NCWidgetClient\NCWidgetClient;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Payment\Helper\Data;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\Method\Logger;
use Magento\Sales\Model\Order;
use Magento\Store\Model\StoreManagerInterface;


class Payment extends AbstractMethod
{
    const CODE = 'netcents_merchant';
    protected $_scopeConfig;
    protected $_code = 'netcents_merchant';
    protected $_isInitializeNeeded = true;
    protected $urlBuilder;
    protected $storeManager;
    protected $scClient;
    protected $resolver;


    /**
     * @param Context $context
     * @param Registry $registry
     * @param ExtensionAttributesFactory $extensionFactory
     * @param AttributeValueFactory $customAttributeFactory
     * @param Data $paymentData
     * @param ScopeConfigInterface $scopeConfig
     * @param Logger $logger
     * @param UrlInterface $urlBuilder
     * @param StoreManagerInterface $storeManager
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     * @internal param ModuleListInterface $moduleList
     * @internal param TimezoneInterface $localeDate
     * @internal param CountryFactory $countryFactory
     * @internal param Http $response
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        Data $paymentData,
        ScopeConfigInterface $scopeConfig,
        Logger $logger,
        UrlInterface $urlBuilder,
        StoreManagerInterface $storeManager,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = array()
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
        $this->_scopeConfig = $scopeConfig;
        $this->urlBuilder = $urlBuilder;
        $this->storeManager = $storeManager;
    }

    public function getApiUrl() {
        $host_url = $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/api_url');
        $parsed = parse_url($host_url);
        if ($host_url == 'https://merchant.net-cents.com') {
            $api_url = 'https://api.net-cents.com';
        } else if ($host_url == 'https://gateway-staging.net-cents.com') {
            $api_url = 'https://api-staging.net-cents.com';
        } else if ($host_url == 'https://gateway-test.net-cents.com') {
            $api_url = 'https://api-test.net-cents.com';
        } else {
            $api_url = $parsed['scheme'] . '://' . 'api.' . $parsed['host'];
        }
        return $api_url;
    }

    public function getTransaction($transactionId) {
        $api_url = $this->getApiUrl();
        $api_key = $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/api_key');
        $api_secret = $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/secret_key');
        $curl = curl_init($api_url . '/merchant/v2/transactions/' . $transactionId);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type:application/json',
            'Authorization:Basic ' . base64_encode($api_key . ':' . $api_secret)
        ));
        return json_decode(curl_exec($curl));
    }

    public function getConfigValue($name) {
        return $this->_scopeConfig->getValue($name);
    }

    /**
     * @param Order $order
     * @return array
     */
    public function getNetCentsResponse(Order $order) {

        $uriCallback = $this->urlBuilder->getUrl('netcents/statusPage/callback');
        $uriSuccess =  $this->urlBuilder->getUrl('netcents/statusPage/success');
        $total = number_format($order->getGrandTotal(), 2, '.', '');

        $payment = new NCPaymentData(
            $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/widget_id'),
            $order->getId(),
            $total,
            $uriSuccess,
            $order->getBillingAddress()->getFirstName(),
            $order->getBillingAddress()->getLastName(),
            $order->getBillingAddress()->getEmail(),
            $uriCallback,
            $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/api_key'),
            $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/secret_key'),
            $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/api_url'),
            $order->getOrderCurrencyCode()
        );

        try {
            $client = new NCWidgetClient($payment);

            $response = $client->encryptData($this->getApiUrl());

            if ($response->status == 200) {
                return [
                    'status' => 'ok',
                    'redirect_url' => $this->_scopeConfig->getValue('payment/netcents_merchant/api_fields/api_url') . '/widget/merchant/widget?data=' . $response->token
                ];
            } else {
                return [
                    'status' => 'error',
                    'errorCode' => 1,
                    'errorMsg' => 'Cant use this payment method at this time'
                ];
            }
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'errorCode' => 1,
                'errorMsg' => 'Error: ' . $e->getMessage()
            ];
        }
    }
}

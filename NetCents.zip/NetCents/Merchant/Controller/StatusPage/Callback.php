<?php
namespace NetCents\Merchant\Controller\StatusPage;

use NetCents\Merchant\Model\Payment as PaymentModel;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\Order;
use Magento\Framework\App\Request\Http;

class Callback extends Action {
    protected $order;
    protected $paymentModel;
    protected $client;
    protected $httpRequest;

    /**
     * @param Context $context
     * @param Order $order
     * @param PaymentModel $paymentModel
     * @internal param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param Http $request
     */
    public function __construct(
        Context $context,
        Order $order,
        PaymentModel $paymentModel,
        Http $request
    ) {
        parent::__construct($context);
        $this->order = $order;
        $this->paymentModel = $paymentModel;
        $this->httpRequest = $request;
    }

    public function execute() {
        $data = json_decode(base64_decode($this->getRequest()->getPost('data')));

        if (is_null($data)) {
            $this->getResponse()->setHttpResponseCode(400);
            return;
        }

        $response = $this->paymentModel->getTransaction($data->transaction_id);
        $status = $response->status;
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->create('\Magento\Sales\Model\Order') ->load($data->external_id);
        if ($order) {
            if ($status == 'paid') {
                $orderPaidStatus = $this->paymentModel->getConfigValue('payment/netcents_merchant/payment_settings/order_status_paid');
                $order->setStatus($orderPaidStatus)->setState($orderPaidStatus)->save();
            }
            if ($status == 'overpaid' || $status == 'underpaid') {
                $orderTestStatus = $this->paymentModel->getConfigValue('payment/netcents_merchant/payment_settings/order_status_test');
                $order->setStatus($orderTestStatus)->setState($orderTestStatus)->save();
            }
            $order->save();
            $this->getResponse()->setBody('*ok*')->sendResponse();
        }
        else {
            $this->getResponse()->setBody('*error*')->sendResponse();
        }
    }
}

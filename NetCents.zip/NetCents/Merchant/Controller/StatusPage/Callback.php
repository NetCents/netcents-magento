<?php

namespace NetCents\Merchant\Controller\StatusPage;

use NetCents\Merchant\Model\Payment as PaymentModel;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\Order;
use Magento\Framework\App\Request\Http;

class Callback extends Action
{
    protected $order;
    protected $paymentModel;
    protected $client;
    protected $httpRequest;
    protected $checkoutSession;
    protected $orderSender;

    /**
     * @param Context $context
     * @param Order $order
     * @param PaymentModel $paymentModel
     * @internal param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param Http $request
     */
    public function __construct(
        Context $context,
        Order $order,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
        PaymentModel $paymentModel,
        Http $request
    ) {
        parent::__construct($context);
        $this->order = $order;
        $this->paymentModel = $paymentModel;
        $this->httpRequest = $request;
        $this->checkoutSession = $checkoutSession;
        $this->orderSender = $orderSender;
    }

    private function completeOrder($order, $payment, $amount_received_in_quoted_currency, $status)
    {
        $order->setStatus($status)->setState($status);
        $order->setTotalPaid($amount_received_in_quoted_currency);
        $order->addStatusToHistory($order->getStatus(), 'Payment has been processed');
        $payment->registerCaptureNotification($amount_received_in_quoted_currency, true);
        $order->save();

        $this
            ->checkoutSession
            ->setForceOrderMailSentOnSuccess(true);
        $this
            ->orderSender
            ->send($order);
        $this
            ->checkoutSession
            ->unsForceOrderMailSentOnSuccess();
    }

    public function execute()
    {
        $data = json_decode(base64_decode($this->getRequest()->getPost('data')));

        if (is_null($data)) {
            $this->getResponse()->setHttpResponseCode(400);
            return;
        }

        $response = $this->paymentModel->getTransaction($data->transaction_id);
        $status = $response->status;
        $amount_received_in_quoted_currency = $response->amount_received_in_quoted_currency;

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->create('\Magento\Sales\Model\Order')->load($data->external_id);
        if ($order) {
            $payment = $order->getPayment();
            if ($status == 'paid') {
                $orderPaidStatus = $this->paymentModel->getConfigValue('payment/netcents_merchant/payment_settings/order_status_paid');
                $this->completeOrder($order, $payment, $amount_received_in_quoted_currency, $orderPaidStatus);
            }
            if ($status == 'overpaid' || $status == 'underpaid') {
                $this->completeOrder($order, $payment, $amount_received_in_quoted_currency, 'payment_review');
            }
            $this->getResponse()->setBody('*ok*')->sendResponse();
        } else {
            $this->getResponse()->setBody('*error*')->sendResponse();
        }
    }
}

# Installation

Move NetCents folder to <magento_installation_path>/app/code/

Run

`sudo php bin/magento setup:upgrade`
`sudo php bin/magento setup:di:compile`

## Configuration

https://merchant-support.net-cents.com/knowledge/magento
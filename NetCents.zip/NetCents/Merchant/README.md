# Installation

Move NetCents folder to <magento_installation_path>/app/code/
- sudo php bin/magento setup:upgrade
- sudo php bin/magento setup:di:compile
<?php

namespace NetCents\Merchant\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

/**
 * Class AfterPlaceOrderObserver
 * @package PayU\PaymentGateway\Observer
 */
class AfterPlaceOrderObserver implements ObserverInterface
{

  /**
   * Store key
   */
  const STORE = 'store';

  /**
   * @var OrderRepositoryInterface
   */
  private $orderRepository;

  /**
   * @var AfterPlaceOrderRepayEmailProcessor
   */
  private $emailProcessor;

  /**
   * StatusAssignObserver constructor.
   *
   * @param OrderRepositoryInterface $orderRepository
   * @param AfterPlaceOrderRepayEmailProcessor $emailProcessor
   */
  public function __construct(
    OrderRepositoryInterface $orderRepository,
    \Magento\Checkout\Model\Session $checkoutSession
  ) {
    $this->orderRepository = $orderRepository;
    $this->checkoutSession = $checkoutSession;
  }

  /**
   * {@inheritdoc}
   */
  public function execute(Observer $observer)
  {
    $payment = $observer->getData('payment');
    $pay_method = $payment->getMethodInstance();
    $code = $pay_method->getCode();

    if ($code == 'netcents_merchant') {
      $this->checkoutSession->setForceOrderMailSentOnSuccess(false);
    }
  }
}
